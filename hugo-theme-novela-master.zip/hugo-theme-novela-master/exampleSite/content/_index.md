---
hero:
  heading: Welcome to Novela, the simplest way to start publishing with Hugo.
  maxWidthPX: 652
seo:
  image: /images/hero-2.jpg
---
